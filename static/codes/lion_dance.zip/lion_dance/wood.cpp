#include "wood.hpp"

Wood::Wood(const std::string& filename) {
    texture_.reset(new Texture(filename, &KeyColor));
}

Rect Wood::GetRect() {
    return Rect{position_.x, position_.y,
                texture_->GetSize().x, texture_->GetSize().y};
}

void Wood::Render() {
    Renderer::Copy(*texture_, position_);
}

Rect Wood::GetCollidRect() {
    auto rect = GetRect();
    rect.y += 7;
    rect.h -= 7;
    rect.x += 10;
    rect.w -= 20;
    return rect;
}
