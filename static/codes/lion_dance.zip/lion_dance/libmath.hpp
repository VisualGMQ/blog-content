#pragma once
#include "SDL.h"
#include <random>
#include <type_traits>

using Point = SDL_FPoint;
using Size = SDL_FPoint;
using Rect = SDL_FRect;
using Color = SDL_Color;

Point operator+(const Point& p1, const Point& p2);
Point operator-(const Point& p1, const Point& p2);
Point operator*(const Point& p1, const Point& p2);
Point operator*(const Point& p, float value);
Point operator*(float value, const Point& p);
Point operator/(const Point& p1, const Point& p2);
Point operator/(const Point& p, float value);
Point operator/(float value, const Point& p);
Point& operator+=(Point& p1, const Point& p2);
Point& operator-=(Point& p1, const Point& p2);
Point& operator*=(Point& p1, const Point& p2);
Point& operator/=(Point& p1, const Point& p2);

SDL_Point Point2SDL(const Point&);
SDL_Rect Rect2SDL(const Rect&);

Point Normalize(const Point& p);

inline Rect CreateRect(const Point& p, const Size& s) {
    return Rect{p.x, p.y, s.x, s.y};
}

inline float Radians(float degress) {
    return degress * M_PI / 180.0;
}

inline Point Rotate(const Point& p, float radians) {
    float cosa = SDL_cos(radians),
          sina = SDL_sin(radians);
    return Point{p.x * cosa + p.y * sina,
                 -p.x * sina + p.y * cosa};
}

Point GetRectCenter(const Rect& rect);

template <typename T>
T Random(const T& low, const T& high) {
    static_assert(std::is_floating_point<T>::value || std::is_integral<T>::value);

    std::random_device device;
    if (std::is_floating_point<T>::value) {
        std::uniform_real_distribution<T> dist(low, high);
        return dist(device);
    } else {
        std::uniform_int_distribution<T> dist(low, high);
        return dist(device);
    }
}

bool IsRectsIntersect(const Rect& r1, const Rect& r2);
Rect RectsIntersect(const Rect& r1, const Rect& r2);
bool IsPointInRect(const Point& p, const Rect& r);

inline char Sign(float value) {
    if (value > 0)
        return 1;
    else if (value < 0)
        return -1;
    else
        return 0;
}

inline float Clamp(float min, float max, float value) {
    if (value > max)
        return max;
    if (value < min)
        return min;
    return value;
}
