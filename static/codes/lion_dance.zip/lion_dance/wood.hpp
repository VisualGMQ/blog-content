#pragma once

#include "texture.hpp"
#include "tool.hpp"
#include "libmath.hpp"
#include "renderer.hpp"
#include "constants.hpp"
#include <string>

class Wood {
public:
    Wood(const std::string& filename);

    void Render();
    const Point& GetPosition() const { return position_; }
    Rect GetRect();
    Rect GetCollidRect();
    void Move(const Point& pos) { position_ = pos; }
    void MoveTo(const Point& offset) { position_ += offset; }

private:
    Unique<Texture> texture_;
    Point position_;
};
