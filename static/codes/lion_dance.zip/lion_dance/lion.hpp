#pragma once

#include "texture.hpp"
#include "tool.hpp"
#include "libmath.hpp"
#include "constants.hpp"
#include "renderer.hpp"
#include "global.hpp"

struct CollideResult {
    Point msv;
};

class Lion {
public:
    Lion();
    const Point& GetPosition() const { return position_; }
    const Size& GetSize() const { return standTexture_->GetSize(); }
    Rect GetRect() const { return CreateRect(GetPosition(), GetSize()); }
    Rect GetCollidRect() const;
    void Move(const Point& pos) { position_ = pos; }
    void MoveOffset(const Point& offset) { position_ += offset; }
    void Render();
    void Jump(const Point& dir);
    void Stand();
    void Update(Uint32 t);
    inline bool IsOnLand() const { return onLand_; }
    void Reset();

private:
    Unique<Texture> standTexture_;
    Unique<Texture> jumpTexture_;
    Texture* curTexture_;
    Point position_;
    Point oldPosition_;
    bool onLand_ = true;
    Point spd_ = {0, 0};
};
