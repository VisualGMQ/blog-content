/*
 * compile:
 * em++ wasm_sdl_demo.cpp -s WASM=1 -s USE_SDL=2 -o index.html
 *
 * run:
 * emrun --port 8080 .
 */
#include "engine.hpp"

SDL_Event event;

void MainLoop() {
    Renderer::Clear();
    engine.EventHandle(event);
    engine.Update();
    engine.Render();
    Renderer::SwapContext();
}

int main(int argc, char** argv) {
    printf("舞狮\n");
    printf("通过点击让舞狮跳跃到指定的木桩上面。成功三次即可通关。\n");
    engine.Init("sandbox", Size{720, 480});

    emscripten_set_main_loop(MainLoop, 60, 1);

    engine.Shutdown();
    return 0;
}
