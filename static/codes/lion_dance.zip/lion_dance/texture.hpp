#pragma once
#include "SDL.h"
#include "libmath.hpp"
#include <string>

class Texture {
public:
    Texture(const std::string& filename, Color* keycolor = nullptr);
    Texture(const Texture&) = delete;
    const Size& GetSize() const { return size_; }
    ~Texture();
    Texture& operator=(const Texture&) = delete;
    SDL_Texture* GetRaw() { return texture_; }
    void SetOpacity(int opacity);

private:
    SDL_Texture* texture_;
    Size size_;
};
