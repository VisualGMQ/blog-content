#pragma once
#include "libmath.hpp"

extern Color KeyColor;
extern Point Gravity;
constexpr float JmpSpd = 6.5;
constexpr int Delay = 20;
