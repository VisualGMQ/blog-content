#include "texture.hpp"
#include "renderer.hpp"

Texture::Texture(const std::string& filename, Color* keycolor) {
    SDL_Surface* surface = SDL_LoadBMP(filename.c_str());
    size_.x = 0;
    size_.y = 0;
    if (!surface) {
        printf("can't load %s", filename.c_str());
    } else {
        printf("surface size(%d, %d)", surface->w, surface->h);
        size_.x = surface->w;
        size_.y = surface->h;
        if (keycolor) {
            SDL_SetColorKey(surface,
                            SDL_TRUE,
                            SDL_MapRGB(surface->format,
                                       keycolor->r,
                                       keycolor->g,
                                       keycolor->b));
        }
        texture_ = SDL_CreateTextureFromSurface(Renderer::GetRaw(), surface);
        if (!texture_) {
            printf("can't create texture from surface %s", filename.c_str());
        }
        SDL_FreeSurface(surface);
    }
}

Texture::~Texture() {
    SDL_DestroyTexture(texture_);
}

void Texture::SetOpacity(int opacity) {
    SDL_SetTextureAlphaMod(texture_, opacity);
}
