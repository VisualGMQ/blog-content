#pragma once

#include <array>
#include "wood.hpp"

extern std::array<Unique<Wood>, 4> Woods;
extern Unique<Texture> Arrow;
extern int WoodIdx;
extern Unique<Texture> RestartBtn;
extern bool BtnShow;
extern int SuccessCount;
