#include "libmath.hpp"

Point operator+(const Point& p1, const Point& p2) {
    return Point{p1.x + p2.x, p1.y + p2.y};
}

Point operator-(const Point& p1, const Point& p2) {
    return Point{p1.x - p2.x, p1.y - p2.y};
}

Point operator*(const Point& p1, const Point& p2) {
    return Point{p1.x * p2.x, p1.y * p2.y};
}

Point operator*(const Point& p, float value) {
    return Point{p.x * value, p.y * value};
}

Point operator*(float value, const Point& p) {
    return p * value;
}

Point operator/(const Point& p1, const Point& p2) {
    return Point{p1.x / p2.x, p1.y / p2.y};
}

Point operator/(const Point& p, float value) {
    return Point{p.x / value, p.y / value};
}

Point operator/(float value, const Point& p) {
    return p * value;
}

Point& operator+=(Point& p1, const Point& p2) {
    p1.x += p2.x;
    p1.y += p2.y;
    return p1;
}

Point& operator-=(Point& p1, const Point& p2) {
    p1.x -= p2.x;
    p1.y -= p2.y;
    return p1;
}

Point& operator*=(Point& p1, const Point& p2) {
    p1.x *= p2.x;
    p1.y *= p2.y;
    return p1;
}

Point& operator/=(Point& p1, const Point& p2) {
    p1.x /= p2.x;
    p1.y /= p2.y;
    return p1;
}

float Len(const Point& p) {
    return SDL_sqrt(p.x * p.x + p.y * p.y);
}

float Len2(const Point& p) {
    return p.x * p.x + p.y * p.y;
}

Point Normalize(const Point& p) {
    return p / Len(p);
}

SDL_Point Point2SDL(const Point& p) {
    return SDL_Point{int(p.x),
                     int(p.y)};
}

Point GetRectCenter(const Rect& rect) {
    return Point{rect.x + rect.w / 2,
                 rect.y + rect.h / 2};
}

SDL_Rect Rect2SDL(const Rect& r) {
    return SDL_Rect{int(r.x),
                    int(r.y),
                    int(r.w),
                    int(r.h)};
}

bool IsRectsIntersect(const Rect& r1, const Rect& r2) {
    return !(r1.x > r2.x + r2.w ||
             r1.x + r1.w < r2.x ||
             r1.y > r2.x + r2.h ||
             r1.y + r1.h < r2.y);
}

Rect RectsIntersect(const Rect& r1, const Rect& r2) {
    SDL_Rect result;
    SDL_Rect rect1 = { int(r1.x), int(r1.y), int(r1.w), int(r1.h)},
             rect2 = { int(r2.x), int(r2.y), int(r2.w), int(r2.h)};
    SDL_IntersectRect(&rect1, &rect2, &result);
    return Rect{float(result.x),
                float(result.y),
                float(result.w),
                float(result.h)};
}

bool IsPointInRect(const Point& p, const Rect& r) {
    return r.x <= p.x && r.y <= p.y && r.x + r.w >= p.x && r.y + r.h >= p.y;
}
