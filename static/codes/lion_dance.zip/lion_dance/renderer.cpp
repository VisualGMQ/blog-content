#include "renderer.hpp"
#include <iostream>

Color Renderer::clearColor_ = {100, 100, 100, 255};
SDL_Renderer* Renderer::renderer_ = nullptr;

void Renderer::Init(SDL_Window* window) {
    Renderer::renderer_ = SDL_CreateRenderer(window, -1, 0);
}

void Renderer::SetClearColor(const Color& color) {
    Renderer::SetDrawColor(color);
}

void Renderer::DrawLine(const Point& p1, const Point& p2) {
    SDL_RenderDrawLineF(renderer_,
                        p1.x, p1.y,
                        p2.x, p2.y);
}

void Renderer::DrawRect(const Rect& rect) {
    SDL_RenderDrawRectF(renderer_, &rect);
}

void Renderer::FillRect(const Rect& rect) {
    SDL_RenderFillRectF(renderer_, &rect);
}

void Renderer::SetDrawColor(const Color& color) {
    SDL_SetRenderDrawColor(renderer_,
                           clearColor_.r,
                           clearColor_.g,
                           clearColor_.b,
                           clearColor_.a);
}

void Renderer::Copy(Texture& texture,
                    const Point& pos,
                    const Size& size,
                    const Color& color) {
    SDL_Rect rect;
    rect.x = pos.x;
    rect.y = pos.y;
    rect.w = size.x;
    rect.h = size.y;

    if (size.x == 0 || size.y == 0) {
        rect.w = texture.GetSize().x;
        rect.h = texture.GetSize().y;
    }
    if (texture.GetRaw()) {
        SDL_SetTextureColorMod(texture.GetRaw(),
                               color.r, color.g, color.b);
        SDL_RenderCopy(Renderer::GetRaw(),
                       texture.GetRaw(),
                       nullptr,
                       &rect);
    }
}


void Renderer::Clear() {
    SDL_RenderClear(renderer_);
}

void Renderer::SwapContext() {
    SDL_RenderPresent(renderer_);
}

void Renderer::Shutdown() {
    SDL_DestroyRenderer(renderer_);
}

SDL_Renderer* Renderer::GetRaw() {
    return renderer_;
}
