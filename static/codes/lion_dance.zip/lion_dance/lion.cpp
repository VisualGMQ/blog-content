#include "lion.hpp"
#include "global.hpp"

Lion::Lion() {
    standTexture_.reset(new Texture("assets/lion_pic1.bmp", &KeyColor));
    jumpTexture_.reset(new Texture("assets/lion_pic2.bmp", &KeyColor));

    Stand();

    position_.x = 0;
    position_.y = 0;
}

Rect Lion::GetCollidRect() const {
    auto rect = GetRect();
    rect.x += 30;
    rect.w -= 60;
    return rect;
}

void Lion::Jump(const Point& dir) {
    curTexture_ = jumpTexture_.get();
    onLand_ = false;
    spd_ = dir;
}

void Lion::Stand() {
    curTexture_ = standTexture_.get();
    onLand_ = true;
    spd_ = {0, 0};
}

void Lion::Render() {
    Renderer::Copy(*curTexture_, position_);
}

CollideResult collide(const Rect& r1, const Rect& r2, const Point& dir) {
    Rect intersect = RectsIntersect(r1, r2);
    Point rectDir{r1.x - r2.x, r1.y - r2.y};
    if (intersect.w < intersect.h) {
        return CollideResult{Point{Sign(dir.x) * -intersect.w, 0}};
    } else if (intersect.w > intersect.h) {
        return CollideResult{Point{0, Sign(dir.y) * -intersect.h}};
    } else {
        if (rectDir.x * dir.x + rectDir.y * dir.y >= 0) {
            if (abs(dir.x) >= abs(dir.y)) {
                return CollideResult{Point{Sign(rectDir.x) * intersect.w,
                                           Sign(rectDir.y) * intersect.h}};
            } else {
                return CollideResult{Point{Sign(rectDir.x) * intersect.w,
                                           Sign(rectDir.y) * intersect.y}};
            }
        } else {
            return CollideResult{Point{dir.x,
                                       Sign(dir.y) * -intersect.h}};
        }
    }
    return CollideResult{};
}

void Lion::Update(Uint32 t) {
    oldPosition_ = GetRectCenter(GetCollidRect());
    if (!onLand_) {
        position_ += spd_ * t + 0.5 * Gravity * t * t;
        spd_ += Gravity * t;
        spd_.y = Clamp(-10, 10, spd_.y);

        Rect playerRect = GetCollidRect();
        auto center = GetRectCenter(GetCollidRect());
        Point offset = center - oldPosition_;
        int idx = 0;
        for (auto& wood : Woods) {
            if (IsRectsIntersect(playerRect, wood->GetCollidRect())) {
                auto result = collide(playerRect, wood->GetCollidRect(),
                                      offset);
                MoveOffset(result.msv);
                if (result.msv.y < result.msv.x && center.y < wood->GetCollidRect().y + 60) {
                    Stand();
                    if (WoodIdx != idx) {
                        BtnShow = true;
                        SuccessCount = 0;
                    } else {
                        SuccessCount ++;
                        WoodIdx = idx;
                        RandIndex();
                    }
                    return;
                }
            }
            idx ++;
        }
    }
}

void Lion::Reset() {
    spd_ = {0, 0};
    onLand_ = true;
}
