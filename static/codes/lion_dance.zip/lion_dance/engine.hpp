#pragma once
#include <string>
#include "SDL.h"
#include "libmath.hpp"
#include "renderer.hpp"
#include "tool.hpp"
#include "wood.hpp"
#include "emscripten.h"
#include "constants.hpp"
#include "global.hpp"

// your game include header
#include "lion.hpp"

class Engine final {
public:
    void Init(const std::string& title, const Size& size);
    void Shutdown();

    void Exit() { shouldExit_ = true; }
    bool ShouldExit() const { return shouldExit_; }

    // TODO implement your logic here
    void Update();
    // TODO implement your render here
    void Render();
    // TODO implement your event handler here
    void EventHandle(SDL_Event&);

private:
    bool shouldExit_ = false;

    // window
    SDL_Window* window_;

    // your members
    Unique<Texture> background_;
    Unique<Lion> lion_;
    Unique<Wood> wood1_;
    Unique<Wood> wood2_;
    Unique<Wood> wood3_;
    Unique<Wood> wood4_;
    Unique<Texture> happyTexture_;
    int opacityTransision_ = 0;
};

extern Engine engine;
