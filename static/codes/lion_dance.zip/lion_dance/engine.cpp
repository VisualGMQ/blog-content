#include "engine.hpp"

void Engine::Init(const std::string& title, const Size& size) {
    SDL_Init(SDL_INIT_EVERYTHING);
    window_ = SDL_CreateWindow(title.c_str(),
                               SDL_WINDOWPOS_CENTERED,
                               SDL_WINDOWPOS_CENTERED,
                               size.x, size.y,
                               SDL_WINDOW_RESIZABLE|SDL_WINDOW_SHOWN);
    Renderer::Init(window_);

    // do your own init
    background_.reset(new Texture("assets/stage.bmp"));
    lion_.reset(new Lion);
    lion_->Move(Point{120, 190});
    Woods[0].reset(new Wood("assets/wood1.bmp"));
    Woods[0]->Move(Point{120, 270});
    Woods[1].reset(new Wood("assets/wood2.bmp"));
    Woods[1]->Move(Point{250, 310});
    Woods[2].reset(new Wood("assets/wood1.bmp"));
    Woods[2]->Move(Point{380, 270});
    Woods[3].reset(new Wood("assets/wood3.bmp"));
    Woods[3]->Move(Point{520, 250});
    Arrow.reset(new Texture("assets/arraw.bmp", &KeyColor));
    RestartBtn.reset(new Texture("assets/restart.bmp", &KeyColor));
    happyTexture_.reset(new Texture("assets/happy.bmp"));
    happyTexture_->SetOpacity(0);

    RandIndex();
}

void Engine::Shutdown() {
    Arrow.reset();
    for (auto& wood : Woods) {
        wood.reset();
    }
    Renderer::Shutdown();
    SDL_DestroyWindow(window_);
    SDL_Quit();
}

void Engine::EventHandle(SDL_Event& e) {
    while (SDL_PollEvent(&e)) {
        if (e.type == SDL_QUIT) {
            Exit();
        }
        if (e.type == SDL_MOUSEBUTTONDOWN) {
            if (e.button.button == SDL_BUTTON_LEFT) {
                // lion jump
                if (lion_->IsOnLand()) {
                    Point dir = Point{float(e.button.x), float(e.button.y)} -
                                GetRectCenter(CreateRect(lion_->GetPosition(), lion_->GetSize()));
                    dir = Normalize(dir) * JmpSpd;
                    lion_->Jump(dir);
                }

                // restart
                if (BtnShow &&
                    IsPointInRect(Point{float(e.button.x), float(e.button.y)},
                                  Rect{50, 50, RestartBtn->GetSize().x, RestartBtn->GetSize().y})) {
                    lion_->Move(Point{120, 190});
                    RandIndex();
                    WoodIdx = 0;
                    BtnShow = false;
                    SuccessCount = 0;
                }
            }
        }
    }
}

void Engine::Update() {
    lion_->Update(1);
    auto pos = lion_->GetPosition();

    if (pos.x < -100 || pos.x > 720 ||
        pos.y > 1000) {
        BtnShow = true;
    }
}

void Engine::Render() {
    Renderer::Copy(*background_, Point{0, 0});
    for (auto& wood : Woods) {
        wood->Render();
    }
    lion_->Render();

    // for collision debug
    // Renderer::SetDrawColor(Color{0, 255, 0, 255});
    // Renderer::DrawRect(lion_->GetCollidRect());
    // for (auto& wood : Woods) {
    //     Renderer::DrawRect(wood->GetCollidRect());
    // }
    // Renderer::SetDrawColor(Color{255, 255, 0, 255});
    // Renderer::DrawRect(Woods[WoodIdx]->GetCollidRect());

    if (lion_->IsOnLand()) {
        Renderer::Copy(*Arrow, Woods[WoodIdx]->GetPosition() + Point{20, -40});
    }

    if (BtnShow) {
        Renderer::Copy(*RestartBtn, Point{50, 50});
    }

    if (SuccessCount >= 4) {
        Renderer::Copy(*happyTexture_, Point{0, 0}, Size{720, 480});
        happyTexture_->SetOpacity(opacityTransision_);
        if (opacityTransision_ < 255)
            opacityTransision_ += 4;
        opacityTransision_ = Clamp(0, 255, opacityTransision_);
    }
}

Engine engine;
