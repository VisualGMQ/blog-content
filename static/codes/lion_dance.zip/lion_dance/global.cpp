#include "global.hpp"

std::array<Unique<Wood>, 4> Woods;
Unique<Texture> Arrow;
int WoodIdx = 0;
Unique<Texture> RestartBtn;
bool BtnShow = false;
int SuccessCount = 0;
