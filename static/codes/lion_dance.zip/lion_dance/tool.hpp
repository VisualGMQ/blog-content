#pragma once

#include <memory>
#include "SDL.h"
#include "libmath.hpp"

template <typename T>
using Unique = std::unique_ptr<T>;

template <typename T>
using Ref = std::shared_ptr<T>;

bool IsLeftBtnPressing();
bool IsRightBtnPressing();
Point GetMousePosition();

void RandIndex();
