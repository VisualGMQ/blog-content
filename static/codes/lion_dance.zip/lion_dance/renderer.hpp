#pragma once
#include "libmath.hpp"
#include "texture.hpp"
#include "SDL.h"

class Renderer final {
public:
    static void Init(SDL_Window* window);
    static void Shutdown();
    static void SetClearColor(const Color& color);
    static void SetDrawColor(const Color& color);
    static void Clear();
    static void DrawLine(const Point& p1, const Point& p2);
    static void DrawRect(const Rect& rect);
    static void FillRect(const Rect& rect);
    static void Copy(Texture& texture, const Point& pos, const Size& size = Size{0, 0}, const Color& = Color{255, 255, 255, 255});
    static void SwapContext();
    static SDL_Renderer* GetRaw();

private:
    static Color clearColor_;

    // render
    static SDL_Renderer* renderer_;
};
