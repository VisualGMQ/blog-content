#include "constants.hpp"

Color KeyColor{255, 40, 198};
Point Gravity{0, 0.098};
