#include "tool.hpp"
#include "global.hpp"

bool IsLeftBtnPressing() {
    return SDL_GetMouseState(nullptr, nullptr) & SDL_BUTTON_LMASK;
}

bool IsRightBtnPressing() {

    return SDL_GetMouseState(nullptr, nullptr) & SDL_BUTTON_RMASK;
}

Point GetMousePosition() {
    int x, y;
    SDL_GetMouseState(&x, &y);
    return Point{float(x), float(y)};
}

void RandIndex() {
    int idx = Random(0, 3);
    while (idx == WoodIdx) {
        idx = Random(0, 3);
    }
    WoodIdx = idx;
}
